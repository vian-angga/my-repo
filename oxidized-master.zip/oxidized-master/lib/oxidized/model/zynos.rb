class ZyNOS < Oxidized::Model
  # Used in Zyxel DSLAMs, such as SAM1316

  comment '! '

  cmd 'config-0'

  cfg :ftp do
  end
end
