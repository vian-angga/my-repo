# IOS parser should work here

require_relative 'ios.rb'

IOSXE = IOS
