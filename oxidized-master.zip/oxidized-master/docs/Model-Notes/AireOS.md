# Cisco WLC Configuration

Create a user with read-write privilege:

```text
mgmtuser add oxidized **** read-write
```

Oxidized needs read-write privilege in order to execute 'config paging disable'.

Back to [Model-Notes](README.md)
