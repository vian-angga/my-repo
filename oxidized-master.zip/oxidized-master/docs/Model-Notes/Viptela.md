# Viptela

This model collects running config and other desired commands from Viptela devices.

Pagination is disabled post login.

## Supported Commands

- show running-config
- show version

Back to [Model-Notes](README.md)
