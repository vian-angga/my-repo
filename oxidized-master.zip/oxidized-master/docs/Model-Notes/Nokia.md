# Nokia

## Nokia ISAM and SSH keepalives

Nokia ISAM might require disabling SSH keepalives.

[Reference](https://github.com/ytti/oxidized/issues/1482)

Back to [Model-Notes](README.md)
